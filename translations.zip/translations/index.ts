export {default as am} from './am.json';
export {default as en} from './en.json';
